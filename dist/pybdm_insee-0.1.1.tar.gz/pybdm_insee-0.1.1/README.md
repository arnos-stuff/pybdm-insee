# My very first package !

This is a very simple package helping people use the [IBDM api from french INSEE](https://api.insee.fr/catalogue/site/themes/wso2/subthemes/insee/pages/item-info.jag?name=BDM&version=V1&provider=insee).